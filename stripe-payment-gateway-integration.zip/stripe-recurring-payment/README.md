# process of Recurring Payment Process

1. recurring.php ---> Product Listing with unique product_id

2. create-checkout-session.php --> receive product_id, change the secret key & path of file 

3. success.php --> with session_id   ---> create-portal-session.php ---> info of Sale

4. cancel.php
