<?php

require 'vendor/stripe/stripe-php/init.php';

// This is your real test secret API key.
\Stripe\Stripe::setApiKey('sk_test_51KmB5KSI2paeDHL7rj52VBWpdHa1EVjOrG0MP8bpBh1Y2nF9YBxIFti8GZo1IHEWRHdal0CHVSen8rnFHJt7klAm008J4VCtDF');

header('Content-Type: application/json');

$YOUR_DOMAIN = 'http://localhost/stripe-recurring-payment/success.php';

try {

  $checkout_session = \Stripe\Checkout\Session::retrieve($_POST['session_id']);

  $return_url = $YOUR_DOMAIN;

  // Authenticate your user.
  // $session = \Stripe\BillingPortal\Session::create([
  //   'customer' => $checkout_session->customer,
  //   'return_url' => $return_url,
  // ]);

  echo '<pre>';
  print_r($checkout_session);
  echo '</pre>';
  die;

  header("HTTP/1.1 303 See Other");
  header("Location: " . $session->url);

} catch (Error $e) {

  http_response_code(500);
  echo json_encode(['error' => $e->getMessage()]);
}