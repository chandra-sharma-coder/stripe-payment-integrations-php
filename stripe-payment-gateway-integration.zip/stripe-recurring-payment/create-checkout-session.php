<?php

require 'vendor/stripe/stripe-php/init.php';

// $publishableKey="pk_test_51KmB5KSI2paeDHL79UH6NbTXBuPJXSdqz4V4Q7erXx8tzsueIjeAUDJmhIv1bGlw3yPUrfHdmzBn  452iedFTr74300936dlu9d";
// $secretKey="sk_test_51KmB5KSI2paeDHL7rj52VBWpdHa1EVjOrG0MP8bpBh1Y2nF9YBxIFti8GZo1IHEWRHdal0CHVSen8rnFHJt7klAm008J4VCtDF";

\Stripe\Stripe::setVerifySslCerts(false);

// This is your test secret API key.
\Stripe\Stripe::setApiKey('sk_test_51KmB5KSI2paeDHL7rj52VBWpdHa1EVjOrG0MP8bpBh1Y2nF9YBxIFti8GZo1IHEWRHdal0CHVSen8rnFHJt7klAm008J4VCtDF');

header('Content-Type: application/json');

$YOUR_DOMAIN = 'http://localhost/stripe-recurring-payment';

try {
  $stripe = new \Stripe\StripeClient('sk_test_51KmB5KSI2paeDHL7rj52VBWpdHa1EVjOrG0MP8bpBh1Y2nF9YBxIFti8GZo1IHEWRHdal0CHVSen8rnFHJt7klAm008J4VCtDF'
  );

  $prices = $stripe->prices->create([
    'unit_amount' => 2000,
    'currency' => 'inr',
    'recurring' => ['interval' => 'day'],
    'product' => $_POST['product_id'],
  ]);
  
  //print_r($prices->id); 

  $checkout_session = \Stripe\Checkout\Session::create([
    'line_items' => [[
      'price' => $prices->id,
      'quantity' => 1,
    ]],
    'mode' => 'subscription',
    'success_url' => $YOUR_DOMAIN . '/success.php?session_id={CHECKOUT_SESSION_ID}',
    'cancel_url' => $YOUR_DOMAIN . '/cancel.php',
  ]);

  header("HTTP/1.1 303 See Other");
  header("Location: " . $checkout_session->url);

} catch (Error $e) {
  http_response_code(500);
  echo json_encode(['error' => $e->getMessage()]);
}